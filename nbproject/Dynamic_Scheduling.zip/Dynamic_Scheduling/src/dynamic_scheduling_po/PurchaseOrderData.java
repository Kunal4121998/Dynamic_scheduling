/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamic_scheduling_po;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import dynamic_scheduling_vendor.Vendors;
import java.util.ArrayList;

/**
 *
 * @author a.bhalerao
 */
public class PurchaseOrderData {
    ArrayList<Purchase_Order> purchase_order;
    
    public PurchaseOrderData(){
        purchase_order =new ArrayList<>();
    }
    
    public ArrayList<Purchase_Order> getPurchaseorder(String plant,String material) throws FilloException{
          Fillo fillo=new Fillo();
          Connection connection=fillo.getConnection("E:\\Dynamic Scheduling\\Dynamic_Scheduling\\ds\\Purchase_Order_Master_File.xlsx");
          String strQuery="Select * from sheet1 where Plant='"+plant+"' and Material='"+material+"' ";
	  Recordset recordset=connection.executeQuery(strQuery); 
           
          while (recordset.next()) {            
             Purchase_Order po=new Purchase_Order();
           if(plant.equals(recordset.getField("Plant"))&&material.equals(recordset.getField("Material")))
           {
              po.setMaterial(material);
              po.setMaterial_name(recordset.getField("Short Text"));
              po.setPlant(plant);
              po.setPo_id(recordset.getField("Purchasing Document"));
              String x=recordset.getField("Order Quantity");
              x=x.replaceAll("[,]", "");
              int z=Integer.parseInt(x)/1000;
              po.setQuantity(z);
              po.setSupplier_name(recordset.getField("Supplier/Supplying Plant"));
              po.setUom(recordset.getField("Order Unit"));
              purchase_order.add(po);
        }
           }
          for (Purchase_Order purchase_order1 : purchase_order) {
              {
                  //System.out.println(purchase_order1.getQuantity());
              }
        }
        return purchase_order;
    }
}
