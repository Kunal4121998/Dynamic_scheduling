/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamic_scheduling_vendor;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import dynamic_scheduling_po.PurchaseOrderData;
import dynamic_scheduling_po.Purchase_Order;
import java.util.ArrayList;

/**
 *
 * @author fast
 */
public class DataVendor {
    ArrayList<Vendors> vendors;
    ArrayList<Purchase_Order> poList;
    PurchaseOrderData po_obj;
    public DataVendor(){
        vendors=new ArrayList<>();
        po_obj=new PurchaseOrderData();
    }
    public ArrayList<Vendors> getvendors(String plant,String material) throws FilloException{
        
        //poList=po_obj.getPurchaseorder(plant, material);
          Fillo fillo=new Fillo();
          Connection connection=fillo.getConnection("E:\\Dynamic Scheduling\\Dynamic_Scheduling\\ds\\Vendor_Master_File.xlsx");
          String strQuery="Select * from sheet1 where Plant='"+plant+"' and Material='"+material+"' ";
	  Recordset recordset=connection.executeQuery(strQuery); 
           
          while (recordset.next()) {            
           Vendors ven =new Vendors();
           if(plant.equals(recordset.getField("Plant"))&&material.equals(recordset.getField("Material")))
           {
              ven.setPlant(plant);
              ven.setMaterial(material);
              ven.setLead_time(Integer.parseInt(recordset.getField("Lead Time")));
              ven.setLot_size(Integer.parseInt(recordset.getField("Lot Size")));
              ven.setName(recordset.getField("Supplier/Supplying Plant"));
              ven.setPlantDescription(recordset.getField("Material Descp"));
              ven.setPer_day_capacity(Integer.parseInt(recordset.getField("Production Capacity Vendor")));
              ven.setStatus(true);
              vendors.add(ven);
        }
           }
        return vendors;
          
    }
    
//    public ArrayList<Vendors> getVendor_with_po() throws FilloException{
//        
//        for(int i=0; i<vendors.size();i++){
//            for(int j=0; j<poList.size();j++){
//                if(vendors.get(i).getPlantDescription().equals(poList.get(j).getMaterial_name())&&vendors.get(i).getName().equals(poList.get(j).getSupplier_name()))
//                {
//                       vendors.get(i).setPo_quantity(poList.get(j).getQuantity());
//                       System.out.println(vendors.get(i).getPo_quantity());
//                }
//            }
//        }
//        
//        return vendors;
//    }
 
    
    
}
