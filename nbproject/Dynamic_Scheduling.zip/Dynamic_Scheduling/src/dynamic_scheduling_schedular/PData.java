/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamic_scheduling_schedular;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;
import javafx.scene.control.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author KUNAL
 */
public class PData {
    
    ArrayList<Data> data;
    Data data1;
    public PData(){
        data=new ArrayList<>();
        data1 =new Data();
    }
    
    public void push() throws FilloException, FileNotFoundException, IOException{
        data1.setPlant_code("1826");
        data1.setPo_number("40000001");
        data1.setMonitoring_type("DAily");
        data1.setPo_quantity("23");
        data1.setVendor_id("1223344");
        data1.setName("kunal");
        data1.setPo_item_no(1);
        data1.setMaterial_no("123456");
        data1.setPart_description("Anmelt");
        data1.setUom("Kg");
        data1.setSchedular_id("1");
        data1.setDate("2");
        data1.setAsn_no("3");
        
        data.add(data1);
        
        
        
        
        
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Java Books");
 

    int rowIndex = 1;

        for (Data d : data) 
 {
        data.iterator().next();
        Row row = sheet.createRow(rowIndex++);

        row.createCell(0).setCellValue(d.getDate());
        row.createCell(1).setCellValue(d.getMaterial_no());
        row.createCell(2).setCellValue(d.getPlant_code());
    }
         
        try (FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx")) {
            workbook.write(outputStream);
        }
       
    }
}
