/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamic_scheduling_schedular;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import dynamic_scheduling_daily.DailyConsumption;
import dynamic_scheduling_daily.dailyConsumptionModel;
import dynamic_scheduling_order.orderDetails;
import dynamic_scheduling_po.PurchaseOrderData;
import dynamic_scheduling_po.Purchase_Order;
import dynamic_scheduling_vendor.DataVendor;
import dynamic_scheduling_vendor.Vendors;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 *
 * @author KUNAL
 */
public class Scheduler {
       DailyConsumption dailyConsumption;
    ArrayList<dailyConsumptionModel> dailyArrayList;
    String date[];
    double consumption[];
    double maxStock;
    double minStock;
    double openingStock[];
    double closingStock[];
    double orderQuantity;
    double orderQuantity1[];
    double lotSize=20;
    int orderIndex=0;
    int storeOrderIndex[];
    String schedule_id;
    String asn_id;
    double Po[];
    ArrayList<orderDetails> orderList;
    ArrayList<orderDetails> orderListOutput;
    int x;
    String currentDate;
    ArrayList<Vendors> vendorList;
    ArrayList<Vendors> vendorList1;
    ArrayList<Purchase_Order> porderList;
    DataVendor dataVendor;
    PurchaseOrderData po_obj;
    int daysBetween;
    String plants;
    String materials;
    boolean check;
    double id=1;
    int dynamicDate;
    int recived;
    public Scheduler(){
        dataVendor =new DataVendor();
        po_obj=new PurchaseOrderData();
        dailyConsumption=new DailyConsumption();
        date =new String[32];
        consumption=new double[32];
        openingStock=new double[50];
        closingStock=new double[50];
        storeOrderIndex=new int[100];
        orderList =new ArrayList<>();
        orderListOutput =new ArrayList<>();
        orderQuantity1=new double[50];
        Po=new double[30];
    }
    
    public void Schedules() throws NumberFormatException, FilloException, IOException{
        dailyConsumption.getData();
        dailyArrayList=dailyConsumption.display();
        plants=dailyArrayList.get(0).getPlant();
        materials=dailyArrayList.get(0).getMaterial();
        vendorList=getVendorWithPo(plants, materials);
        DataInitialization();
        maxStock_and_minStock(plants,materials);
        dynamicDate=currentDate();
        openingStock[0]=getOpeningStock(plants,materials);
        System.out.println(dynamicDate);
        for(int i=0; i<dailyArrayList.size(); i++){
            closingStock[i]=openingStock[i]-consumption[i];
            if(closingStock[i]<minStock){
            orderQuantity=maxStock-closingStock[i];
            double k=orderQuantity/lotSize;
            int l=(int) Math.round(k);
            orderQuantity=l*lotSize;
            int o=index(i);
            recived=i;
            x=orderIndex++;
            orderQuantity1[i]=orderQuantity-getVendors(o,orderQuantity);
            closingStock[i]=orderQuantity1[i]+closingStock[i];
            storeOrderIndex[orderIndex]=i;
            
        }
        openingStock[i+1]=closingStock[i];
    }   
        displaySchedules();
        displayOutput();
        store();
        transitQuantity();
    }
    
    private void displaySchedules(){
         for(int i=0; i<dailyArrayList.size(); i++){
             System.out.println(date[i]+" "+openingStock[i]+" "+consumption[i]+" "+closingStock[i]+" "+orderQuantity1[i] );
    }     
    }

    private void maxStock_and_minStock(String plant, String material) throws FilloException {
         
          Fillo fillo=new Fillo();
          Connection connection=fillo.getConnection("E:\\Dynamic Scheduling\\Dynamic_Scheduling\\ds\\Storage_Capacity.xlsx");
  
          String strQuery="Select * from sheet1 where Plant='"+plant+"' and Material='"+material+"' ";
	  Recordset recordset=connection.executeQuery(strQuery);  
          while (recordset.next()) {            
             maxStock=Double.parseDouble(recordset.getField("Maximum Storage Capacity"));
              minStock=Double.parseDouble(recordset.getField("Minimum Storage Capacity"));
        }
             
        
    }

    private void DataInitialization() {
         for(int i=0; i<dailyArrayList.size(); i++){
            consumption[i]=dailyArrayList.get(i).getDaily();
            date[i]=dailyArrayList.get(i).getDate();
             //System.out.println(date[i]);
        }
    }

    private double getOpeningStock(String plant, String material) throws FilloException {
          Fillo fillo=new Fillo();
          Connection connection=fillo.getConnection("E:\\Dynamic Scheduling\\Dynamic_Scheduling\\ds\\Opening_Stock.xlsx");
          double opening = 0;
          String strQuery="Select * from sheet1 where Plant='"+plant+"' and Material='"+material+"' ";
	  Recordset recordset=connection.executeQuery(strQuery);  
          while (recordset.next()) {            
           opening=Double.parseDouble(recordset.getField("Unrest Qty"));
        }
        return opening; //To change body of generated methods, choose Tools | Templates.
    }

    private int index(int i) {
        SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
        currentDate=date[0];
        
       
            String date1=date[i];
            try {
	       Date dateBefore = myFormat.parse(currentDate);
	       Date dateAfter = myFormat.parse(date1);
	       long difference = dateAfter.getTime() - dateBefore.getTime();
	       daysBetween = (int) (difference / (1000*60*60*24)); 
               //System.out.println(daysBetween);
	 } catch (Exception e) {
	 }   
            return daysBetween;
    }
    
    private ArrayList<Vendors> getVendorWithPo(String plant, String material) throws FilloException {
         vendorList1=dataVendor.getvendors(plant, material);
         porderList=po_obj.getPurchaseorder(plant, material);
        
                 for(int i=0; i<vendorList1.size();i++){
                  for(int j=0; j<porderList.size();j++){
                   if(vendorList1.get(i).getPlantDescription().equals(porderList.get(j).getMaterial_name())&&vendorList1.get(i).getName().equals(porderList.get(j).getSupplier_name()))
                    {
                       vendorList1.get(i).setPo_quantity(porderList.get(j).getQuantity());
                       vendorList1.get(i).setPurhase_document(porderList.get(j).getPo_id());
                       
                       //System.out.println(vendorList1.get(i).getPo_quantity());
                    }
                }
          }
               
                 return vendorList1;
    }
    
        private double getVendors(int daysbetween,double oQ) throws FilloException, IOException {
            for (int i=0; i<orderIndex;i++){
            Collections.sort(vendorList);
            for(int z=0; z<vendorList.size(); z++){
                if(vendorList.get(z).getLead_time()<=daysBetween && vendorList.get(z).isStatus()){
                    if(vendorList.get(z).getPo_quantity()>0 && oQ!=0){
                    if(vendorList.get(z).getPer_day_capacity()<=oQ){ 
                             orderDetails order =new orderDetails();
                             order.setPo_number(vendorList.get(z).getPurhase_document());
                             order.setPlant_code(plants);
                             order.setPart_description(vendorList.get(z).getPlantDescription());
                             random_Schedule_id_and_Asn_id();
                             order.setSchedular_id(schedule_id);
                             order.setMaterial_no(materials);
                             order.setAsn_no(asn_id);
                             order.setUom(porderList.get(0).getUom());
                             order.setMonitoring_type("daily");
                             order.setDate(date[daysbetween-vendorList.get(z).getLead_time()]);
                             order.setName(vendorList.get(z).getName());
                             order.setOrderRecived(date[recived]);
                             if(vendorList.get(z).getPer_day_capacity()<=vendorList.get(z).getPo_quantity()){
                                 order.setPo_quantity(String.valueOf(vendorList.get(z).getPo_quantity()));
                                 order.setOrder_quantity(vendorList.get(z).getPer_day_capacity());
                                 vendorList.get(z).setPo_quantity(vendorList.get(z).getPo_quantity()-vendorList.get(z).getPer_day_capacity());        
                                 vendorList.get(z).setStatus(false);
                                 oQ-=vendorList.get(z).getPer_day_capacity();
                                 orderList.add(order);
                             }else{
                                 order.setOrder_quantity(vendorList.get(z).getPo_quantity());
                                 order.setPo_quantity(String.valueOf(vendorList.get(z).getPo_quantity()));
                                 vendorList.get(z).setPo_quantity(vendorList.get(z).getPo_quantity()-vendorList.get(z).getPo_quantity());
                                 vendorList.get(z).setStatus(false);
                                 oQ-=vendorList.get(z).getPo_quantity();
                                 orderList.add(order);
                             }
                             
                    }else{
                             orderDetails order =new orderDetails();
                             order.setUom(porderList.get(0).getUom());
                             order.setPo_number(vendorList.get(z).getPurhase_document());
                             order.setPlant_code(plants);
                             order.setPart_description(vendorList.get(z).getPlantDescription());
                             random_Schedule_id_and_Asn_id();
                             order.setSchedular_id(schedule_id);
                             order.setMaterial_no(materials);
                             order.setAsn_no(asn_id);
                             order.setUom("Kg");
                             order.setMonitoring_type("daily");
                             order.setDate(date[daysbetween-vendorList.get(z).getLead_time()]);
                             order.setName(vendorList.get(z).getName());
                             order.setOrderRecived(date[recived]);
                             if(oQ<=vendorList.get(z).getPo_quantity()){
                             order.setOrder_quantity(oQ);
                             order.setPo_quantity(String.valueOf(vendorList.get(z).getPo_quantity()));
                             vendorList.get(z).setPo_quantity(vendorList.get(z).getPo_quantity()-(int)(oQ));
                             vendorList.get(z).setStatus(false);
                             oQ-=oQ;
                             orderList.add(order);
                    }else{
                                 order.setOrder_quantity(vendorList.get(z).getPo_quantity());
                                 order.setPo_quantity(String.valueOf(vendorList.get(z).getPo_quantity()));
                                 vendorList.get(z).setPo_quantity(vendorList.get(z).getPo_quantity()-vendorList.get(z).getPo_quantity()); 
                                 vendorList.get(z).setStatus(false);
                                 oQ-=vendorList.get(z).getPo_quantity();
                                 orderList.add(order);
                             }
                    }
                    }
                }
            }
            }
            
            for(int i=0; i<vendorList.size(); i++){
                vendorList.get(i).setStatus(true);
            }
          
             if(oQ!=0){return oQ; }
        return 0;
    }
        
        public void displayOutput() throws FileNotFoundException, IOException{
            
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.createSheet("Java Books");
            
            
            for(orderDetails orderDetails1: orderList){
           
                   Row row = sheet.createRow(0);
                   row.createCell(0).setCellValue("Plant Code");
                   row.createCell(1).setCellValue("PO Number");
                   row.createCell(2).setCellValue("Monitoring Type");
                   row.createCell(3).setCellValue("PO Qunatity");
                   row.createCell(4).setCellValue("Vendor ID");
                   row.createCell(5).setCellValue("Vendor Name");
                   row.createCell(6).setCellValue("PO item No.");
                   row.createCell(7).setCellValue("Material Number");
                   row.createCell(8).setCellValue("Part Description");
                   row.createCell(9).setCellValue("UOM");
                   row.createCell(10).setCellValue("Schedule ID");
                   row.createCell(11).setCellValue("Date of Dispatch");
                   row.createCell(12).setCellValue("Qty to be Dispatched");
                   row.createCell(13).setCellValue("ASN No. (Auto Generated)");
                    row.createCell(14).setCellValue("Recived");
                   														

        }
            
            int rowIndex = 1;
            
        for(orderDetails orderDetails1: orderList){
            System.out.println(orderDetails1.getUom()+" "+orderDetails1.getPlant_code()+" "+orderDetails1.getPo_number()+" "+orderDetails1.getDate()+" "+orderDetails1.getOrder_quantity()+" "+orderDetails1.getName());
          
                   Row row = sheet.createRow(rowIndex++);
                   row.createCell(0).setCellValue(orderDetails1.getPlant_code());
                   row.createCell(1).setCellValue(orderDetails1.getPo_number());
                   row.createCell(2).setCellValue(orderDetails1.getMonitoring_type());
                   row.createCell(3).setCellValue(orderDetails1.getPo_quantity());
                   row.createCell(4).setCellValue(orderDetails1.getVendor_id());
                   row.createCell(5).setCellValue(orderDetails1.getName());
                   row.createCell(6).setCellValue(orderDetails1.getPo_item_no());
                   row.createCell(7).setCellValue(orderDetails1.getMaterial_no());
                   row.createCell(8).setCellValue(orderDetails1.getPart_description());
                   row.createCell(9).setCellValue(orderDetails1.getUom());
                   row.createCell(10).setCellValue(orderDetails1.getSchedular_id());
                   row.createCell(11).setCellValue(orderDetails1.getDate());
                   row.createCell(12).setCellValue(orderDetails1.getOrder_quantity());
                   row.createCell(13).setCellValue(orderDetails1.getAsn_no());
                   row.createCell(14).setCellValue(orderDetails1.getOrderRecived());        }
         
            System.out.println(vendorList.size());
            
            try (FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx")) {
            workbook.write(outputStream);
        }
    }   
        
        public void random_Schedule_id_and_Asn_id() throws FileNotFoundException, IOException{
            File src=new File("E:\\Dynamic Scheduling\\Dynamic_Scheduling\\Schedule_and_asn.xlsx");
            FileInputStream fileInputStream =new FileInputStream(src);
            XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
            XSSFSheet xSSFSheet=workbook.getSheetAt(0);
            schedule_id=xSSFSheet.getRow(0).getCell(0).getStringCellValue();
            asn_id=xSSFSheet.getRow(1).getCell(0).getStringCellValue();
            if(schedule_id.equals("yes")&&asn_id.equals("yes")){
                schedule_id="SCH_ID_"+id;
                asn_id="ASN_ID_"+id;
                System.out.println(schedule_id);
                xSSFSheet.getRow(0).createCell(0).setCellValue("no");
                xSSFSheet.getRow(0).createCell(1).setCellValue(id);
                 xSSFSheet.getRow(1).createCell(0).setCellValue("no");
                xSSFSheet.getRow(1).createCell(1).setCellValue(id);
         }else{
                id=xSSFSheet.getRow(0).getCell(1).getNumericCellValue();
                id++;
                schedule_id="SCH_ID_"+id;
                asn_id="ASN_ID_"+id;
                xSSFSheet.getRow(0).createCell(1).setCellValue(id);
                xSSFSheet.getRow(1).createCell(1).setCellValue(id);
            }
            FileOutputStream fout =new FileOutputStream(src);
            workbook.write(fout);
            workbook.close();
        }
       public void store(){
           for(int i=0; i<dailyArrayList.size(); i++){
               if(orderQuantity1[i]!=0){
                   System.out.println(orderQuantity1[i]+" "+date[i]);
               }
           }
       }
       
       public int currentDate(){
           SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
           Date date1=new Date();
           String todayDate=myFormat.format(date1);
           for(int i=0; i<dailyArrayList.size(); i++){
               if(todayDate.equals(date[i])){
                   return i;
               } 
           }
           return 0;
       }
       
       public void transitQuantity() throws FilloException, FileNotFoundException, IOException{
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.createSheet("Test");
            
               
            for(int i=0; i<dailyArrayList.size(); i++){
                Row row = sheet.createRow(0);
                   row.createCell(0).setCellValue("Date");
                   row.createCell(1).setCellValue("Quantity");
            }
                  				
            int rowIndex = 1;
            
        for(int i=0; i<dailyArrayList.size(); i++){
                   if(orderQuantity1[i]!=0)
                   {
                     Row row = sheet.createRow(rowIndex++);
                     row.createCell(0).setCellValue(date[i]);
                     row.createCell(1).setCellValue(orderQuantity1[i]);
                   }
                   
                   
        }
         
            System.out.println(vendorList.size());
            
            try (FileOutputStream outputStream = new FileOutputStream("test.xlsx")) {
            workbook.write(outputStream);
        }
       }
      
}
