/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamic_scheduling_schedular;

/**
 *
 * @author KUNAL
 */
public class Data {
    private String date;
    private String name;
    private double order_quantity;
    private String plant_code;
    private String po_number;
    private String monitoring_type;
    private String po_quantity;
    private String vendor_id;
    private int po_item_no;
    private String material_no;
    private String part_description;
    private String uom;
    private String schedular_id;
    private String asn_no;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getOrder_quantity() {
        return order_quantity;
    }

    public void setOrder_quantity(double order_quantity) {
        this.order_quantity = order_quantity;
    }

    public String getPlant_code() {
        return plant_code;
    }

    public void setPlant_code(String plant_code) {
        this.plant_code = plant_code;
    }

    public String getPo_number() {
        return po_number;
    }

    public void setPo_number(String po_number) {
        this.po_number = po_number;
    }

    public String getMonitoring_type() {
        return monitoring_type;
    }

    public void setMonitoring_type(String monitoring_type) {
        this.monitoring_type = monitoring_type;
    }

    public String getPo_quantity() {
        return po_quantity;
    }

    public void setPo_quantity(String po_quantity) {
        this.po_quantity = po_quantity;
    }

    public String getVendor_id() {
        return vendor_id;
    }

    public void setVendor_id(String vendor_id) {
        this.vendor_id = vendor_id;
    }

    public int getPo_item_no() {
        return po_item_no;
    }

    public void setPo_item_no(int po_item_no) {
        this.po_item_no = po_item_no;
    }

    public String getMaterial_no() {
        return material_no;
    }

    public void setMaterial_no(String material_no) {
        this.material_no = material_no;
    }

    public String getPart_description() {
        return part_description;
    }

    public void setPart_description(String part_description) {
        this.part_description = part_description;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getSchedular_id() {
        return schedular_id;
    }

    public void setSchedular_id(String schedular_id) {
        this.schedular_id = schedular_id;
    }

    public String getAsn_no() {
        return asn_no;
    }

    public void setAsn_no(String asn_no) {
        this.asn_no = asn_no;
    }
    
    
}
