/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamic_scheduling;

import com.codoid.products.exception.FilloException;
import dynamic_scheduling_schedular.PData;
import dynamic_scheduling_schedular.Schedular;
import dynamic_scheduling_schedular.Scheduler;
import java.io.IOException;

/**
 *
 * @author fast
 */
public class Dynamic_Scheduling {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NumberFormatException, FilloException, IOException {
        // TODO code application logic here
        Scheduler scheduler =new Scheduler();
        scheduler.Schedules();
//        Schedular schedular =new Schedular();
//        schedular.Schedules();
//        PData data=new PData();
//        data.push();
    }
    
}
